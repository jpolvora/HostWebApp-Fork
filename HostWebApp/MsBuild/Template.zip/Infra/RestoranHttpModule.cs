using System;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Security;
using Frankstein.Common;
using Frankstein.Common.Mvc;
using Frankstein.Common.Mvc.Authentication;
using Restoran.Entities;

namespace Restoran.Infra
{
    public class RestoranHttpModule : IHttpModule
    {
        public void Init(HttpApplication context)
        {
            context.PostAuthenticateRequest += ContextOnPostAuthenticateRequest;
        }

        private static void ContextOnPostAuthenticateRequest(object sender, EventArgs eventArgs)
        {
            var application = (HttpApplication)sender;
           
            var context = application.Context;
            var user = context.User;
            var request = context.Request;
            var response = context.Response;

            //authentication type set in web.config
            if (user == null || string.IsNullOrEmpty(user.Identity.AuthenticationType))
                return;

            var formsIdentity = user.Identity as FormsIdentity;
            if (formsIdentity == null)
                return;

            if (!user.Identity.IsAuthenticated)
            {
                return;
            }

            try
            {
                var usuario = FetchFromDb(user.Identity.Name);

                if (usuario == null || !usuario.Status)
                {
                    //faz o logout!
                    FormsAuthentication.SignOut();
                    if (!request.IsAjaxRequest())
                    {
                        context.RedirectSafe(FormsAuthentication.LoginUrl);
                    }
                    else
                    {
                        response.StatusCode = 401;
                    }
                    return;
                }

                var restoranPrincipal = new DbPrincipal<Usuario>(formsIdentity, usuario);

                Thread.CurrentPrincipal = context.User = restoranPrincipal;
            }
            catch (Exception ex)
            {
                LogEvent.Raise("Restoran_ContextOnPostAuthenticateRequest", ex);
                ex.SendExceptionToDeveloper("Restoran_ContextOnPostAuthenticateRequest");
            }
        }

        public void Dispose()
        {

        }

        static Usuario FetchFromDb(string email)
        {
            using (var ctx = new RestoranCtx())
            {
                var usuario = ctx.Usuarios.FirstOrDefault(x => x.Email.Equals(email, StringComparison.OrdinalIgnoreCase));
                return usuario;
            }
        }
    }
}