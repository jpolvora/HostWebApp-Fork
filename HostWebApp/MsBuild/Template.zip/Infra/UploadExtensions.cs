using System;
using System.Configuration;
using System.IO;
using System.Web;
using CloudinaryDotNet.Actions;
using Frankstein.Common;

namespace Restoran.Infra
{
    public static class UploadExtensions
    {
        public static string SaveUploadedFile(this HttpPostedFileBase file, string serverFolder)
        {
            // Verify that the user selected a file
            if (file == null || file.ContentLength <= 0)
            {
                return string.Empty;
            }

            var cfg = ConfigurationManager.AppSettings.Get("imageRepository");
            switch (cfg)
            {
                case "cloudinary":
                    return UseCloudinary(file);
                default:
                    return UseLocalFolder(file, serverFolder);
            }
        }

        static string UseCloudinary(HttpPostedFileBase file)
        {

            var uploadParams = new ImageUploadParams
            {
                File = new FileDescription(file.FileName, file.InputStream),
                PublicId = Path.GetFileNameWithoutExtension(file.FileName).URLFriendly()
            };

            var uploadResult = CloudinaryExtensions.Instance.Upload(uploadParams);

            var url = CloudinaryExtensions.Instance.Api.UrlImgUp.BuildUrl(String.Format("{0}.{1}", uploadResult.PublicId, uploadResult.Format));
            return url;
        }

        static string UseLocalFolder(HttpPostedFileBase file, string serverFolder)
        {
            //const string mappath = "~/Content/uploads/estabelecimentos";

            try
            {
                var tempFileName = Path.GetTempFileName();
                file.SaveAs(tempFileName);

                var folder = HttpContext.Current.Server.MapPath(serverFolder);
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                var fileName = string.Format("{0}_{1}", Path.GetFileNameWithoutExtension(tempFileName), Path.GetFileName(file.FileName).URLFriendly());

                if (fileName.Length >= 100)
                {
                    var extension = Path.GetExtension(fileName);
                    var fileN = Path.GetFileNameWithoutExtension(fileName) ?? "";
                    fileName = string.Format("{0}.{1}", fileN.Substring(0, 97), extension);
                }
                var path = Path.Combine(folder, fileName);
                File.Move(tempFileName, path);

                var relativePath = Path.GetFileName(path) ?? "";

                return Path.Combine(serverFolder, relativePath);
            }
            catch (Exception ex)
            {
                LogEvent.Raise("Erro upload arquivo", ex);
                return string.Empty;
            }
        }
    }
}