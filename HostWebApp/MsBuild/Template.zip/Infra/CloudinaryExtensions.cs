﻿using System.Configuration;
using CloudinaryDotNet;

namespace Restoran.Infra
{
    public static class CloudinaryExtensions
    {
        public static Cloudinary Instance
        {
            get;
            private set;
        }

        static CloudinaryExtensions()
        {
            //<add key="CLOUDINARY_URL" value="cloudinary://856323548975687:RsfHLItKEGb8Z9-hCeHxP6X5hVM@hxjabrmeb" />
            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get("CLOUDINARY_URL")))
            {
                var account = new Account("hxjabrmeb", "856323548975687", "RsfHLItKEGb8Z9-hCeHxP6X5hVM");
                Instance = new Cloudinary(account);
            }
            else
            {
                Instance = new Cloudinary(ConfigurationManager.AppSettings.Get("CLOUDINARY_URL"));
            }
        }
    }
}