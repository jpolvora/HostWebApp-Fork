﻿using System.Diagnostics;
using System.Web.Compilation;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Razor;
using System.Web.Routing;
using System.Web.WebPages;
using System.Web.WebPages.Razor;
using Frankstein.Common;
using Frankstein.Common.Configuration;
using Frankstein.PluginLoader;
using Microsoft.Web.Helpers;
using Microsoft.Web.Infrastructure.DynamicModuleHelper;
using Restoran.Entities;
using Restoran.Infra;
using Frankstein.Common.Mvc;

/* Necessário apenas para registrar o módulo de autorização de Usuários do Restoran */
[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(PluginStart), "PreStart")]
namespace Restoran.Infra
{
    public class PluginStart : IPlugin
    {
        private static readonly object _lock = new object();
        private static bool _initialized;
        public string PluginName
        {
            get { return "Plugin-Restoran"; }
        }

        /// <summary>
        /// Registra o módulo de autorização de usuários Restoran
        /// </summary>
        public static void PreStart()
        {
            //somente no prestart
            //BuildProvider.RegisterBuildProvider(".csmd", typeof(RazorBuildProvider));
            //RazorCodeLanguage.Languages.Add("csmd", new CSharpRazorCodeLanguage());
            //WebPageHttpHandler.RegisterExtension("csmd");

            DynamicModuleUtility.RegisterModule(typeof(RestoranHttpModule));
        }

        public void Start()
        {
            lock (_lock)
            {
                if (_initialized)
                    return;

                _initialized = true;
            }

            WebPageRazorHost.AddGlobalImport("Restoran");
            WebPageRazorHost.AddGlobalImport("Restoran.Entities");
            WebPageRazorHost.AddGlobalImport("Restoran.Models");
            WebPageRazorHost.AddGlobalImport("Restoran.Infra");

            var bundles = BundleTable.Bundles;
            var root = WebPagesHtmlHelpers.MapPath("");

            bundles.Add(new ScriptBundle("~/bundles/js")
                       .Include("~/Scripts/jquery-1.11.1.min.js")
                       .Include("~/Scripts/jquery.validate.min.js")
                       .Include("~/Scripts/jquery.validate.unobtrusive.min.js")
                       .Include("~/Scripts/jquery.unobtrusive-ajax.min.js")
                       .Include("~/Scripts/bootstrap.min.js")
                       .Include(root + "/Assets/Scripts/jquery.lazyload.min.js")
                       .Include(root + "/Assets/Scripts/globalize/globalize.js")
                       .Include(root + "/globalize/cultures/globalize.culture.pt-BR.js")
                       .Include(root + "/Assets/Scripts/jquery.mask.min.js")
                       .Include(root + "/Assets/Scripts/holder.js")
                       .Include(root + "/Assets/Scripts/scripts.js")
                       .Include(root + "/Assets/Scripts/menu.js")
                       );

            bundles.Add(new StyleBundle("~/bundles/css")
                .Include("~/Content/bootstrap.min.css")
                //.Include("~/Content/bootstrap-theme.min.css")
                .Include("~/Content/font-awesome.min.css")
                .Include(root + "/Assets/bootstrap-social.css")
                .Include(root + "/Assets/styles/styles.css")
                .Include(root + "/Assets/styles/site.css")
                );

            //BundleTable.EnableOptimizations = true;

            /*
             * Verificar no Frankstein.Config se insertroutes=true
             */

            var routes = RouteTable.Routes;
            routes.RouteExistingFiles = false;
            routes.LowercaseUrls = true;
            routes.AppendTrailingSlash = true;

            routes.MapWebPageRoute("{cidade}/estabelecimentos", root + "/estabelecimentos.cshtml");
            //routes.MapRoute(
            //    name: "Default",
            //    url: "{controller}/{action}/{id}",
            //    defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            //);


            using (DisposableTimer.StartNew("Initializing RestoranCtx"))
            {
                using (var ctx = new RestoranCtx())
                {
                    ctx.Database.Initialize(false);
                }
            }

            ReCaptcha.PublicKey = "6LfBmfoSAAAAABiZwGcyhZiu-e2Ug8PqZaxo7mCm";
            ReCaptcha.PrivateKey = "6LfBmfoSAAAAAFZ_9fjR8aa8obvE4wUWg1tD_8Df";

            RequestCheck.FirstRequest += RequestCheckOnFirstRequest;
        }

        private void RequestCheckOnFirstRequest(object sender, System.EventArgs e)
        {
            Trace.TraceInformation("First request tracing... (restoran.pluginstart) {0}", RequestCheck.HostUrl);
            RequestCheck.FirstRequest -= RequestCheckOnFirstRequest;
        }
    }
}