﻿using System;
using System.Configuration;
using System.IO;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.WebPages;
using CloudinaryDotNet;
using Restoran.Entities;

namespace Restoran.Infra
{
    public static class HtmlHelpers
    {
      

        public static string FullUrl(this UrlHelper helper, string relativeUrl)
        {
            var @base = ConfigurationManager.AppSettings["site:host"];
            var path = helper.Content(relativeUrl);

            return string.Format("http://{0}/{1}", @base, path);
        }

        public static string Image(this WebPageRenderingBase page, string path, int width, int height)
        {
            if (string.IsNullOrWhiteSpace(path))
                return string.Empty;

            if (!path.StartsWith("~/"))
            {
                if (IsUrl(path))
                {
                    if (IsCloudinary(path))
                    {
                        var uri = new Uri(path);

                        var fileName = Path.GetFileName(uri.LocalPath);
                        var newPath = CloudinaryExtensions.Instance.Api.UrlImgUp.Transform(new Transformation().Width(
                            width)
                            .Height(height)).BuildUrl(fileName);

                        return newPath;
                    }

                    return path;
                }

                return CloudinaryExtensions.Instance.Api.UrlImgUp.Transform(new Transformation().Width(width)
                    .Height(height)).BuildUrl(path);
            }

            var helper = new UrlHelper(new RequestContext(page.Context, page.Request.RequestContext.RouteData));

            var relativePath = helper.Content(path);

            var ctx = helper.RequestContext.HttpContext;

            var fullPath = ctx.Server.MapPath(relativePath);
            if (File.Exists(fullPath))
                return relativePath;

            return path;
        }

        static bool IsCloudinary(string url)
        {
            return !string.IsNullOrWhiteSpace(url) && url.Contains("://res.cloudinary.com");
        }

        static bool IsUrl(string url)
        {
            return !string.IsNullOrWhiteSpace(url) && url.StartsWith("http") && url.Contains("://");
        }

        public static string Image(this WebPageRenderingBase page, Foto foto, int width, int height)
        {
            if (foto != null)
            {
                return Image(page, foto.ImagePath, width, height);
            }

            return string.Empty;
        }

        public static string FormatTelefone(this string phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber))
                return string.Empty;

            string result = phoneNumber;

            if (phoneNumber.Length == 10)
            {
                result = string.Format("({0}) {1}-{2}", phoneNumber.Substring(0, 2), phoneNumber.Substring(2, 4),
                    phoneNumber.Substring(6));
            }
            else if (phoneNumber.Length == 11)
            {
                result = string.Format("({0}) {1}-{2}", phoneNumber.Substring(0, 2), phoneNumber.Substring(2, 5),
                    phoneNumber.Substring(7));
            }

            return result;
        }
    }
}