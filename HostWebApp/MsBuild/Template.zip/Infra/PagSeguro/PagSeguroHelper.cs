﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml.Linq;
using Frankstein.Common;

namespace Restoran.Infra.PagSeguro
{
    public class PagSeguroHelper
    {
        const string GETNOTIFICACAO = "https://ws.pagseguro.uol.com.br/v2/transactions/notifications";
        const string CHECKOUT = "https://ws.pagseguro.uol.com.br/v2/checkout";
        //const string CHECKOUT_TESTE = "http://localhost:9090/checkout/checkout.jhtml";
        public static string EMAIL { get; private set; }
        public static string TOKEN { get; private set; }

        public static string GetLinkPagamento(string transacao)
        {
            return string.Format("https://pagseguro.uol.com.br/v2/checkout/payment.html?code={0}", transacao);
        }

        static PagSeguroHelper()
        {
            EMAIL = ConfigurationManager.AppSettings["pagseguro:email"];
            TOKEN = ConfigurationManager.AppSettings["pagseguro:token"];
        }

        public static async Task<PagSeguroResponse> ProcessaPagamento(InfoPagamento info)
        {
            using (var httpClient = new HttpClient())
            {
                var content = CreateRequest(info);

                var response = await httpClient.PostAsync(CHECKOUT, content).ConfigureAwait(false);
                var result = await response.Content.ReadAsStringAsync();

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    return CreateResponse(result);
                }
                return new PagSeguroResponse() { Msg = result };
            }
        }

        public static async Task<PagSeguroStatus> ConsultaStatus(string transacao)
        {
            var parameters = string.Format("email={0}&token={1}", EMAIL, TOKEN);
            var fmtTarget = string.Format("{0}/{1}?{2}", GETNOTIFICACAO, transacao, parameters);

            using (var httpClient = new HttpClient())
            {
                var response = await httpClient.GetAsync(fmtTarget).ConfigureAwait(false);

                var result = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    try
                    {
                        var doc = XDocument.Parse(result);
                        var reference = Convert.ToInt64(doc.Root.Element("reference").Value);
                        var status = Convert.ToInt32(doc.Root.Element("status").Value);
                        var paymentMethod = doc.Root.Elements("paymentMethod").First();
                        var pmType = paymentMethod.Element("type");
                        var pmCode = paymentMethod.Element("code");
                        var shipping = doc.Root.Elements("shipping").First();
                        var address = shipping.Element("address");
                        var street = address.Element("street");
                        var number = address.Element("number");
                        var complement = address.Element("complement");
                        var district = address.Element("district");
                        var postalCode = address.Element("postalCode");
                        var city = address.Element("city");
                        var state = address.Element("state");

                        string pmTypeStr = string.Empty;
                        switch (pmType.Value)
                        {
                            case "1":
                                {
                                    pmTypeStr = "Cartão de Crédito";
                                    break;
                                }
                            case "2":
                                {
                                    pmTypeStr = "Boleto";
                                    break;
                                }
                            case "3":
                                {
                                    pmTypeStr = "Débito online (TEF)";
                                    break;
                                }
                            case "4":
                                {
                                    pmTypeStr = "Saldo PagSeguro";
                                    break;
                                }
                            case "5":
                                {
                                    pmTypeStr = "Oi Paggo";
                                    break;
                                }
                            case "7":
                                {
                                    pmTypeStr = "Depósito em conta";
                                    break;
                                }
                        }

                        var statusResult = new PagSeguroStatus()
                        {
                            Reference = reference,
                            Status = (PagSeguroTransactionStatus)status,
                            Street = street.Value,
                            Number = number.Value,
                            Complement = complement.Value,
                            District = district.Value,
                            PostalCode = postalCode.Value,
                            City = city.Value,
                            State = state.Value,
                            FormaDePagamento = string.Format("PagSeguro ({0})", pmTypeStr)
                        };

                        return statusResult;
                    }
                    catch (Exception ex)
                    {
                        LogEvent.Raise("ConsultaStatus", ex);
                        return new PagSeguroStatus() { Exception = ex.Message };
                    }
                }

                return new PagSeguroStatus() { Exception = result };
            }
        }

        #region helpers

        static FormUrlEncodedContent CreateRequest(InfoPagamento info)
        {
            var request = new Dictionary<string, string>
            {
                {"Content-Type", "application/x-www-form-urlencoded; charset=ISO-8859-1"},
                {"email", EMAIL},
                {"token", TOKEN},
                {"currency", "BRL"},
                {"itemId1", info.CodigoProduto.ToString()},
                {"itemDescription1", info.DescricaoProduto},
                {"itemAmount1", info.Valor.ToString("F").Replace(",", ".")},
                {"itemQuantity1", 1.ToString()},
                {"reference", info.CodigoCompra.ToString()},
                {"senderName", info.NomeComprador},
                {"senderEmail", info.EmailComprador},
                {"senderCPF", info.CpfComprador},
                {"senderBornDate", string.Format("{0:dd/MM/yyyy}", info.DataNascto)},
                {"redirectURL", info.RedirectUrl},
                {"notificationURL", info.ReturnUrl}
            };

            if (!string.IsNullOrEmpty(info.Telefone) && info.Telefone.Length > 2)
            {
                request.Add("senderAreaCode", info.Telefone.Substring(0, 2));
                request.Add("senderPhone", info.Telefone.Substring(2));
            }

            return new FormUrlEncodedContent(request);
        }

        static PagSeguroResponse CreateResponse(string xmlResult)
        {
            try
            {
                var doc = XDocument.Parse(xmlResult);

                var code = doc.Root.Element("code");
                var date = doc.Root.Element("date");
                return new PagSeguroResponse() { Code = code.Value, Date = date.Value };
            }
            catch (Exception ex)
            {
                LogEvent.Raise("ProcessaPagamento", ex);

                return new PagSeguroResponse() { Msg = ex.Message };
            }
        }

        #endregion
    }

    public class InfoPagamento
    {
        public string NomeComprador { get; set; }
        public string EmailComprador { get; set; }
        public string CpfComprador { get; set; }
        public string Telefone { get; set; }
        public Int64 CodigoProduto { get; set; }
        public Int64 CodigoCompra { get; set; }
        public string DescricaoProduto { get; set; }
        public decimal Valor { get; set; }
        public DateTime DataNascto { get; set; }
        public string RedirectUrl { get; set; }
        public string ReturnUrl { get; set; }
        public string TransacaoPagSeguro { get; set; }
    }

    public class PagSeguroResponse
    {
        public string Code { get; set; }
        public string Date { get; set; }
        public string Msg { get; set; }

        public PagSeguroStatus PagSeguroStatus { get; set; }
    }

    public class PagSeguroStatus
    {
        public long Reference { get; set; }
        public PagSeguroTransactionStatus Status { get; set; }
        public string Exception { get; set; }
        public string Street { get; set; }
        public string Number { get; set; }
        public string Complement { get; set; }
        public string District { get; set; } //Bairro
        public string PostalCode { get; set; } //cep
        public string City { get; set; }
        public string State { get; set; }

        public string FormaDePagamento { get; set; }
    }

    public enum PagSeguroTransactionStatus
    {
        Pendente = 0,
        Aguardando_Pagamento = 1,
        Em_Análise = 2,
        Paga = 3,
        Disponível = 4,
        Em_Disputa = 5,
        Devolvida = 6,
        Cancelada = 7
    }
}