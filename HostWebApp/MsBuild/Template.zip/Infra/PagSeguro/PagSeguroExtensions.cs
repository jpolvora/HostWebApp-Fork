using System;
using System.Configuration;
using System.Web;
using Frankstein.Common;
using Frankstein.Common.Mvc;
using Restoran.Entities;

namespace Restoran.Infra.PagSeguro
{
    public static class PagSeguroExtensions
    {
        public static InfoPagamento CreateFromCartao(this Cartao cartao, HttpContextBase context)
        {
            //retorna a transa��o

            var infoPagamento = new InfoPagamento()
            {
                CpfComprador = cartao.Usuario.Cpf,
                DataNascto = cartao.Usuario.DataNascto.GetValueOrDefault(),
                CodigoProduto = cartao.PlanoId,
                DescricaoProduto = string.Format("{0} (ref. {1})", cartao.Plano.Nome, cartao.Id),
                EmailComprador = cartao.Usuario.Email,
                NomeComprador = cartao.Usuario.Nome,
                Telefone = string.IsNullOrEmpty(cartao.Usuario.Telefone)
                    ? ""
                    : cartao.Usuario.Telefone.Replace("-", "").Replace("(", "").Replace(")", "").Replace(" ", ""),
                CodigoCompra = cartao.Id,
                Valor = cartao.Plano.ValorVista,
                RedirectUrl = context.ToPublicUrl(new Uri("/clube/sucesso.cshtml?compra={0}".Fmt(cartao.NumeroCartao), UriKind.Relative), Uri.UriSchemeHttp),
                ReturnUrl = context.ToPublicUrl(new Uri("/ajax/pagseguronotification.cshtml", UriKind.Relative), Uri.UriSchemeHttp)
            };

            string host = ConfigurationManager.AppSettings["site:host"];
            string port = ConfigurationManager.AppSettings["site:port"];

            var builderRedirectUrl = new UriBuilder(infoPagamento.RedirectUrl)
            {
                Host = host,
                Port = Convert.ToInt32(port)
            };
            infoPagamento.RedirectUrl = new Uri(builderRedirectUrl.Uri.ToString(), UriKind.Absolute).AbsoluteUri;

            var builderReturnUrl = new UriBuilder(infoPagamento.ReturnUrl)
            {
                Host = host,
                Port = 80
            };
            infoPagamento.ReturnUrl = new Uri(builderReturnUrl.Uri.ToString(), UriKind.Absolute).AbsoluteUri;


            var transacao = PagSeguroHelper.ProcessaPagamento(infoPagamento).Result.Code;
            infoPagamento.TransacaoPagSeguro = transacao;

            return infoPagamento;

        }
    }
}