﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Web.Helpers;
using Frankstein.Common;
using Restoran.Entities;

namespace Restoran.Infra
{
    public class CacheInitializer
    {
        private static readonly object Locker = new object();

        public static void Init()
        {
            using (DisposableTimer.StartNew("Locking"))
            {
                lock (Locker)
                {
                    using (var ctx = new RestoranCtx())
                    {
                        List<Cidade> cidades = WebCache.Get("cidades");
                        if (cidades == null)
                        {
                            Trace.TraceInformation("Fetching Cidades");
                            cidades = ctx.Cidades.Where(x => x.Status).OrderBy(x => x.Nome).ToList();
                            WebCache.Set("cidades", cidades);
                        }

                        List<Categoria> categorias = WebCache.Get("categorias");
                        if (categorias == null)
                        {
                            Trace.TraceInformation("Fetching Categorias");
                            categorias = ctx.Categorias.Where(x => x.Status).OrderBy(x => x.Descricao).ToList();
                            WebCache.Set("categorias", categorias);
                        }

                        List<Empresa> empresas = WebCache.Get("empresas");
                        if (empresas == null)
                        {
                            Trace.TraceInformation("Fetching Empresas");
                            empresas = ctx.Empresas
                                .Include(x => x.EmpresaCategorias)
                                .Include(x => x.EmpresaCategorias.Select(s => s.Categoria))
                                .Include(x => x.Fotos)
                                .Include(x => x.HorariosFuncionamento)
                                .Where(x => x.Status)
                                .OrderBy(x => x.Nome)
                                .ToList();
                            WebCache.Set("empresas", empresas);
                        }
                    }
                }
            }
        }
    }
}