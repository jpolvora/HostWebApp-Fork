﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.Net.Mail;
using System.Text;
using System.Threading;
using Frankstein.Common.Configuration;
using Frankstein.Common.Mvc;
using Restoran.Models;

namespace Restoran.Infra
{
    public static class EmailHelper
    {
        public static void SendEmailInfoPagamento(string email, string nome, string numeroCartao)
        {
            var model = new EmailModel("Restoran - Pagamento confirmado")
            {
                Email = email,
                Nome = nome,
                Token = numeroCartao
            };

            var msg = ViewRenderer.RenderView("~/App_Data/Views/EmailTemplates/infopagamento.cshtml", model);

            SendMail(email, msg, BootstrapperSection.Instance.Mail.MailAdmin, model.Title, true);
        }

        public static void SendEmailCompraSucessoAssociado(string email, string nome, string link)
        {
            var model = new EmailModel("Restoran - Aguardando o pagamento.")
            {
                Email = email,
                Nome = nome,
                Link = link
            };

            var msg = ViewRenderer.RenderView("~/App_Data/Views/EmailTemplates/CompraSucessoAssociado.cshtml", model);

            SendMail(email, msg, BootstrapperSection.Instance.Mail.MailAdmin, model.Title, true);
        }

        public static void SendEmailNewAccount(string nome, string email)
        {

            var model = new EmailModel("Restoran - Cadastro confirmado")
            {
                Email = email,
                Nome = nome
            };

            var msg = ViewRenderer.RenderView("~/App_Data/Views/EmailTemplates/NewAccount.cshtml", model);

            SendMail(email, msg, BootstrapperSection.Instance.Mail.MailAdmin, model.Title, true);
        }

        /// <summary>
        /// Ao enviar este email, o email será confirmado automaticamente para proseguir com a compra (passo 3)
        /// </summary>
        public static void SendEmailPagamento(string nome, string email, string token, int plano)
        {
            var model = new EmailModel("Restoran - Código de Ativação p/ Compra")
            {
                Email = email,
                Nome = nome,
                Token = token,
                Link = string.Format("http://{0}/clube/email.cshtml?source=email&token={1}&plano={2}&email={3}", ConfigurationManager.AppSettings["site:host"], token, plano, email)
            };

            var msg = ViewRenderer.RenderView("~/App_Data/Views/EmailTemplates/ativacaocompra.cshtml", model);

            SendMail(email, msg, BootstrapperSection.Instance.Mail.MailAdmin, model.Title, true);
        }

        /// <summary>
        /// Ao enviar este email, o email será confirmado automaticamente para proseguir com a compra (passo 3)
        /// </summary>
        public static void SendEmailConfirmacao(string nome, string email, string token)
        {
            var model = new EmailModel("Restoran - Código de Ativação p/ Confirmação")
            {
                Email = email,
                Nome = nome,
                Token = token,
                Link = string.Format("http://{0}/Areas/session/confirmacao.cshtml?source=email&token={1}&email={2}", ConfigurationManager.AppSettings["site:host"], token, email)
            };

            var msg = ViewRenderer.RenderView("~/App_Data/Views/EmailTemplates/ativacaoconta.cshtml", model);

            SendMail(email, msg, BootstrapperSection.Instance.Mail.MailAdmin, model.Title, true);
        }

        public static void SendEmailNotificaIndicado(string emailIndicado, string emailIndicador, string link)
        {
            var model = new EmailModel("Restoran - Programa de indicados")
            {
                Email = emailIndicador,
                Nome = emailIndicado,
                Link = link
            };

            var msg = ViewRenderer.RenderView("~/App_Data/Views/EmailTemplates/notificaindicador.cshtml", model);

            SendMail(model.Email, msg, BootstrapperSection.Instance.Mail.MailAdmin, model.Title, true);
        }

        public static void SendResetPasswordRequest(string email, string url)
        {
            var model = new EmailModel("Restoran - Reset de Senha")
            {
                Email = email,
                Link = url
            };

            var msg = ViewRenderer.RenderView("~/App_Data/Views/EmailTemplates/passwordreset.cshtml", model);

            SendMail(model.Email, msg, BootstrapperSection.Instance.Mail.MailAdmin, model.Title, true);
        }

        public static void SendPasswordChanged(string email)
        {
            var model = new EmailModel("Restoran - Senha alterada")
            {
                Email = email,
                Body = "Senha alterada com sucesso.",
                Link = string.Format("http://{0}?source=email", ConfigurationManager.AppSettings["site:host"])
            };

            var msg = ViewRenderer.RenderView("~/App_Data/Views/EmailTemplates/empty.cshtml", model);

            SendMail(model.Email, msg, BootstrapperSection.Instance.Mail.MailAdmin, model.Title, true);


            //const string body = "Senha alterada com sucesso.";
            //var reply = EntropiaSection.Instance.AdminMail;
            //const string subject = "Restoran - Alteração de Senha";

            //SendMail(email, body, reply, subject);
        }

        public static void SendNotificationToAdmin(string subject, string body)
        {
            string email = BootstrapperSection.Instance.Mail.MailAdmin;

            SendMail(email, body, email, subject);
        }

        public static void SendNotificationToDeveloper(string subject, string body)
        {
            string email = BootstrapperSection.Instance.Mail.MailDeveloper;

            SendMail(email, body, email, subject);
        }       

        public static void SendMail(string email, string body, string reply, string subject,
            bool html = false)
        {
            if (string.IsNullOrEmpty(reply))
            {
                reply = BootstrapperSection.Instance.Mail.MailDeveloper;
            }

            var msg = new MailMessage();
            msg.To.Add(email);
            msg.Body = body;
            msg.IsBodyHtml = html;
            msg.ReplyToList.Add(reply);
            msg.Subject = subject;
            msg.BodyEncoding = Encoding.UTF8;

            var msgId = Guid.NewGuid().ToString("P");
            Trace.TraceInformation("[Email]:[{0}] Enqueue email delivery to '{1}' with subject: '{2}'", msgId, msg.To[0], msg.Subject);
            ThreadPool.QueueUserWorkItem(x => 
                Frankstein.Common.EmailExtensions.SendEmail(new MailAddress(reply), new MailAddress(email), subject,
                body, !html, EmailError));

        }

        private static void EmailError(MailMessage arg1, Exception arg2)
        {
            if (arg2 == null)
            {
                Trace.TraceInformation("[Email]:[{0}] was sent", arg1);
            }
            else
            {
                Trace.TraceError("[Email]:[{0}] fail with {1}", arg1, arg2.Message);
            }
        }
    }
}