using System.Security.Principal;
using Frankstein.Common.Mvc.Authentication;
using Restoran.Entities;

/* N�o est� sendo utilizada, mas j� est� implementado em caso de futuras necessidades
 * Ao utilizar esta classe, alterar o RestoranHttpModule para instanciar esta classe ao inv�s da classe base.
 */
namespace Restoran.Infra
{

    //public static class RestoranPrincipalExtensions
    //{
    //    public static RestoranPrincipal FromCurrent(this IPrincipal principal)
    //    {
    //        var current = principal as RestoranPrincipal;
    //        return current ?? new RestoranPrincipal(principal.Identity, new Usuario());
    //    }
    //}

    //public class RestoranPrincipal : DbPrincipal<Usuario>
    //{
    //    public RestoranPrincipal(IIdentity identity, Usuario dbUser)
    //        : base(identity, dbUser)
    //    {
    //    }

    //    public static implicit operator Usuario(RestoranPrincipal instance)
    //    {
    //        return instance.DbUser;
    //    }

    //}
}