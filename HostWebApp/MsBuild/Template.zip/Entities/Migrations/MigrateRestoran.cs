using System.Data.Entity;

namespace Restoran.Entities.Migrations
{
    public class MigrateRestoran : MigrateDatabaseToLatestVersion<RestoranCtx, Configuration>
    {
        
    }
}