using System.Data.Entity;

namespace Restoran.Entities.Migrations
{
    public class RestoranMigrationInitializer : MigrateDatabaseToLatestVersion<RestoranCtx, RestoranMigrationConfiguration>
    {
        
    }
}