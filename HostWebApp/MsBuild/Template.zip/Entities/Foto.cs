﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Fotos")]
    public class Foto : AuditableEntity<long>
    {
        [ForeignKey("EmpresaId")]
        public Empresa Empresa { get; set; }

        [Required, StringLength(200)]
        public string ImagePath { get; set; }

        [StringLength(120)]
        public string Alt { get; set; }

        [Required]
        public int EmpresaId { get; set; }
    }
}