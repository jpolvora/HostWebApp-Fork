﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Cidades")]
    public class Cidade : AuditableEntity<int>
    {
        [Required, StringLength(100)]
        public string Nome { get; set; }
        [Required, MapToChar(2)]
        public string Uf { get; set; }

        [StringLength(120)]
        public string Permalink { get; set; }

        public override string ToString()
        {
            return string.Format("{0} -{1}", Nome, Uf);
        }
    }
}