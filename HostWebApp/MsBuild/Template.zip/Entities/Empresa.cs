﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Empresas")]
    public class Empresa : AuditableEntity<int>
    {
        public Empresa()
        {
            Fotos = new Collection<Foto>();
            EmpresaCategorias = new Collection<EmpresaCategoria>();
            HorariosFuncionamento = new Collection<HorarioFuncionamento>();
        }

        [Required, StringLength(128)]
        public string Nome { get; set; }

        [StringLength(140)]
        public string Permalink { get; set; }

        [Required] //maxlength
        public string Descricao { get; set; }

        [StringLength(200)]
        public string ImagePath { get; set; }

        [Required, StringLength(15)]
        public string Cnpj { get; set; }

        public int? CidadeId { get; set; }

        public bool IsParceiro { get; set; }

        public bool IsRestaurante { get; set; }

        //varchar(max)
        public string DescricaoDetalhada { get; set; }

        [ForeignKey("CidadeId")]
        public Cidade Cidade { get; set; }

        [StringLength(11)]
        public string Telefone { get; set; }

        [StringLength(400)]
        public string Endereco { get; set; }

        [StringLength(200)]
        public string UrlSite { get; set; }

        [DecimalMapping(10, 2)]
        public decimal? FaixaDePrecoInicial { get; set; }

        [DecimalMapping(10, 2)]
        public decimal? FaixaDePrecoFinal { get; set; }

        [StringLength(25)]
        public string LatitudeLongitude { get; set; }

        public bool Visivel { get; set; }

        public int QtdeLancamentosAlerta { get; set; }

        public ICollection<Foto> Fotos { get; set; }

        public ICollection<EmpresaCategoria> EmpresaCategorias { get; set; }

        public ICollection<HorarioFuncionamento> HorariosFuncionamento { get; set; }

        public ICollection<Operador> Operadores { get; set; }


    }
}