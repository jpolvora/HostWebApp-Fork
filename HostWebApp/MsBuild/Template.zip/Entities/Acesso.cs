﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.Common;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Acessos")]
    public class Acesso : AuditableEntity<long>
    {
        [StringLength(5)]
        public string Method { get; set; }

        public int StatusCode { get; set; }

        [StringLength(20)]
        public string RenderingTime { get; set; }

        [StringLength(200), Display(Name = "Detalhes da Operação")]
        public string Operacao { get; set; }

        [NotMapped]
        public string OperacaoResumida
        {
            get
            {
                return Operacao.Truncate(50);
            }
        }

        [StringLength(120)]
        public string UserAgent { get; set; }

        [NotMapped]
        public string UserAgentTruncado
        {
            get
            {
                return UserAgent.Truncate(50);
            }
        }

        [StringLength(15), Display(Name = "Ip")]
        public string IpAddress { get; set; }

        [Display(Name = "Via router")]
        public bool Router { get; set; }

        public bool IsMobile { get; set; }

        [StringLength(40)]
        public string RouteName { get; set; }
    }
}