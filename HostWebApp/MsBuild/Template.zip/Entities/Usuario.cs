﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.Common.Mvc.Authentication;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Usuarios")]
    public class Usuario : AuditableEntity<long>, IDbUser
    {
        public Usuario()
        {
            Operadores = new HashSet<Operador>();
            Cartoes = new HashSet<Cartao>();
        }

        public long? IndicadoPorId { get; set; }

        [StringLength(50)]
        public string Link { get; set; }

        [Required, StringLength(11, MinimumLength = 11), Index(IsUnique = true)]
        public string Cpf { get; set; }

        [Required, StringLength(60)]
        public string PrimeiroNome { get; set; }

        [Required, StringLength(128)]
        public string Sobrenome { get; set; }

        [Required, StringLength(128), Index(IsUnique = true)]
        public string Email { get; set; }

        [StringLength(11)]
        public string Telefone { get; set; }

        public DateTime? DataNascto { get; set; }

        [MapToChar(1), StringLength(1), Required]
        public string Sexo { get; set; }

        [Required] //tem acesso a área de sócios
        public bool IsAssociado { get; set; }

        [Required] //tem acesso ao gerenciamento do sistema
        public bool IsAdmin { get; set; }

        [Required] //tem acesso à área do lojista (é um operador de empresa do tipo RESTAURANTE)
        public bool IsLojista { get; set; }

        [Required] //tem acesso à área restrita do site (é um operador do site)
        public bool IsOperador { get; set; }

        [Required] //tem acesso à área de parceiros (é um operador do tipo PARCEIRO)
        public bool IsParceiro { get; set; }

        [Required, MapToChar(8)]
        public string Salt { get; set; }

        [Required, MapToChar(44)]
        public string Senha { get; set; }

        public Guid? ResetToken { get; set; }

        [ForeignKey("IndicadoPorId")]
        public Usuario IndicadoPor { get; set; }

        //indica se o usuário confirmou email recebido
        public bool EmailConfirmado { get; set; }

        [Index]
        public Guid? TokenConfirmacaoEmail { get; set; }

        [NotMapped]
        public string Nome
        {
            get
            {
                return string.Format("{0} {1}", PrimeiroNome, Sobrenome);
            }
        }



        public ICollection<Operador> Operadores { get; set; }
        public ICollection<Cartao> Cartoes { get; set; }

        public List<string> GetRoles()
        {
            var roles = new List<string>();

            if (IsOperador)
                roles.Add("Operador");

            if (IsAdmin)
            {
                roles.Add("Admin");
                roles.Add("DEVELOPERS");
            }

            if (IsLojista)
                roles.Add("Lojista");

            if (IsParceiro)
                roles.Add("Parceiro");

            if (IsAssociado)
                roles.Add("Associado");

            return roles;
        }
    }
}