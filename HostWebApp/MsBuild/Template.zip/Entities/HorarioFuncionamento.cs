﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("HorariosFuncionamento")]
    public class HorarioFuncionamento : AuditableEntity<long>
    {
        [Required]
        public DayOfWeek Dia { get; set; }

        public DayOfWeek DiaFim { get; set; }

        [Required]
        public short Inicio { get; set; }

        [Required]
        public short Fim { get; set; }

        [ForeignKey("EmpresaId")]
        public Empresa Empresa { get; set; }

        public int EmpresaId { get; set; }
    }
}