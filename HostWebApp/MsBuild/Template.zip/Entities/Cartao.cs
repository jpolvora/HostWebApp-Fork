﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    public enum TipoCartao
    {
        Normal = 0,
        Trial = 1,
        PessoaJuridica = 2
    }


    [Table("Cartoes")]
    public class Cartao : AuditableEntity<long>
    {
        [Required]
        public long UsuarioId { get; set; }

        [Required]
        public int PlanoId { get; set; }

        //se for tipo 2 (PJ), então procurar empresa pelo campo EmpresaId
        public TipoCartao TipoCartao { get; set; }

        public int? EmpresaId { get; set; }

        [Required, StringLength(17), Index(IsUnique = true)]
        public string NumeroCartao { get; set; }

        [Required, StringLength(128)]
        public string NomeImpresso { get; set; }

        public bool Liberado { get; set; }

        public DateTime? DataLiberacao { get; set; }

        /// <summary>
        /// Soma da Data de Pagamento + Dias creditados pelo produto comprado
        /// </summary>
        public DateTime? Validade { get; set; }

        /// <summary>
        /// Indica se o cartão foi ou não entregue ao usuário
        /// </summary>
        public bool Entregue { get; set; }

        //endereço de entrega do cartão
        [StringLength(100)]
        public string Endereco { get; set; }

        [StringLength(10)]
        public string EndNumero { get; set; }

        [StringLength(25)]
        public string EndCompl { get; set; }

        [StringLength(80)]
        public string Bairro { get; set; }

        [StringLength(80)]
        public string Cidade { get; set; }

        [MapToChar(2)]
        public string Uf { get; set; }

        [StringLength(8)]
        public string Cep { get; set; }

        [ForeignKey("UsuarioId")]
        public Usuario Usuario { get; set; }

        [ForeignKey("PlanoId")]
        public Plano Plano { get; set; }

        [ForeignKey("EmpresaId")]
        public Empresa Empresa { get; set; }

        //campos pagseguro

        [StringLength(60)]
        public string FormaDePagamento { get; set; }

        [StringLength(50)]
        public string Transacao { get; set; }

        [StringLength(40)]
        public string Notificacao { get; set; }

        public int StatusNotificacao { get; set; }

        public DateTime? DataNotificacao { get; set; }

        public override string ToString()
        {
            if (Usuario != null)
            {
                return string.Format("{0} - {1}", Usuario, NumeroCartao);
            }
            return NumeroCartao;
        }
    }
}