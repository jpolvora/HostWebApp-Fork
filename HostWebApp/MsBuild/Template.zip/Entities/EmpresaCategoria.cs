﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Empresas_Categorias")]
    public class EmpresaCategoria : AuditableEntity<int>
    {
        [ForeignKey("EmpresaId")]
        public Empresa Empresa { get; set; }

        [ForeignKey("CategoriaId")]
        public Categoria Categoria { get; set; }

        [Required]
        public int EmpresaId { get; set; }

        [Required]
        public int CategoriaId { get; set; }
    }
}