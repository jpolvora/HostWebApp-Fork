﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Categorias")]
    public class Categoria : AuditableEntity<int>
    {
        [Required, StringLength(100)]
        public string Descricao { get; set; }
    }
}