﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Empresas_Planos")]
    public class EmpresaPlano : AuditableEntity<int>
    {
        [ForeignKey("EmpresaId")]
        public Empresa Empresa { get; set; }

        [ForeignKey("PlanoId")]
        public Plano Plano { get; set; }

        [Required]
        public int EmpresaId { get; set; }

        [Required]
        public int PlanoId { get; set; }
    }
}