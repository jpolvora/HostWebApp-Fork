using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    public class Cupom : AuditableEntity<long>
    {
        [Required, StringLength(12)]
        public string Numero { get; set; }

        [ForeignKey("PlanoId")]
        public Plano Plano { get; set; }
        [Required]
        public int PlanoId { get; set; }

        [ForeignKey("UsuarioId")]
        public Usuario Usuario { get; set; }

        public int? UsuarioId { get; set; }
    }
}