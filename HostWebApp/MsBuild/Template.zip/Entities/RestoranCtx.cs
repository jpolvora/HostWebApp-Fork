﻿using System;
using System.Data.Entity;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    public class RestoranCtx : DbContextBase
    {
        static RestoranCtx()
        {
            Database.SetInitializer(new NullDatabaseInitializer<RestoranCtx>());
        }

        public DbSet<Empresa> Empresas { get; set; }
        public DbSet<EmpresaPlano> EmpresaPlanos { get; set; }
        public DbSet<Operador> Operadores { get; set; }
        public DbSet<Plano> Planos { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Cartao> Cartoes { get; set; }
        public DbSet<Lancamento> Lancamentos { get; set; }

        public DbSet<Cidade> Cidades { get; set; }
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<EmpresaCategoria> EmpresaCategorias { get; set; }
        public DbSet<Foto> Fotos { get; set; }
        public DbSet<HorarioFuncionamento> HorariosFuncionamento { get; set; }

        public DbSet<Acesso> Acessos { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Properties<decimal>().Configure(config => config.HasPrecision(10, 2));
            modelBuilder.Properties<DateTime>().Configure(x => x.HasColumnType("datetime2"));

            base.OnModelCreating(modelBuilder);
        }
    }
}