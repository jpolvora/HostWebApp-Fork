﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Planos")]
    public class Plano : AuditableEntity<int>
    {
        [Required, StringLength(128)]
        public string Nome { get; set; }

        [Required]
        public string Descricao { get; set; }

        [StringLength(200)]
        public string ImagePath { get; set; }

        [Required, DecimalMapping(10, 2), DataType(DataType.Currency)]
        public decimal ValorVista { get; set; }

        [DecimalMapping(10, 2)]
        public decimal ValorPrazo { get; set; }

        [Required]
        public int QtdeDias { get; set; }

        [Required]
        public int QtdeUtilizacoes { get; set; }

        [Required]
        public bool Trial { get; set; }

        [Required]
        public bool Publicar { get; set; }

        public override string ToString()
        {
            return string.Format("{0}-{1}", Id, Nome);
        }
    }
}