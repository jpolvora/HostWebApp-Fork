﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Lancamentos")]
    public class Lancamento : AuditableEntity<long>
    {
        [Required]
        public int EmpresaId { get; set; }

        [Required]
        public long CartaoId { get; set; }

        [Required, DecimalMapping(10, 2), DataType(DataType.Currency)]
        public decimal TotalConsumo { get; set; }

        [Required]
        public int QtdePessoas { get; set; }

        [Required, DecimalMapping(10, 2), DataType(DataType.Currency)]
        public decimal TotalDesconto { get; set; }

        [ForeignKey("EmpresaId")]
        public Empresa Empresa { get; set; }

        [ForeignKey("CartaoId")]
        public Cartao Cartao { get; set; }
    }
}