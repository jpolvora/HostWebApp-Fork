﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Frankstein.EntityFramework;

namespace Restoran.Entities
{
    [Table("Operadores")]
    public class Operador : AuditableEntity<long>
    {
        [ForeignKey("EmpresaId")]
        public Empresa Empresa { get; set; }

        [ForeignKey("UsuarioId")]
        public Usuario Usuario { get; set; }

        [Required]
        public int EmpresaId { get; set; }

        [Required]
        public long UsuarioId { get; set; }

        [Required]//indica se é admin dentro da empresa
        public bool IsAdmin { get; set; }
    }
}