﻿using System.Web.Mvc;

namespace Restoran.Controllers
{
    [RoutePrefix("home")]
    [Route("{action=restoran}")]
    public class HomeController : Controller
    {
        public ActionResult Restoran()
        {
            ViewBag.Titulo = "Controller Restoran Home";
            return View();
        }
    }
}