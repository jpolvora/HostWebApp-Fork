namespace Restoran.Models
{
    public class EmailModel
    {
        public EmailModel(string title, string body = "")
        {
            Title = title;
            Body = body;
        }

        public EmailModel()
        {
        }

        public string Title { get; set; }

        public string Body { get; set; }

        public string Email { get; set; }

        public string Nome { get; set; }

        public string Link { get; set; }

        public string Token { get; set; }
    }
}

