﻿(function (window, culture) {
    var $ = window.jQuery,
        jQuery = window.jQuery;

    /*prototypes*/

    Number.prototype.formatMoney = function (c, d, t) {
        var n = this,
            c = isNaN(c = Math.abs(c)) ? 2 : c,
            d = d == undefined ? "." : d,
            t = t == undefined ? "," : t,
            s = n < 0 ? "-" : "",
            i = parseInt(n = Math.abs(+n || 0).toFixed(c), 10) + "",
            j = (j = i.length) > 3 ? j % 3 : 0;
        return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
    };

    if (!String.prototype.format) {
        String.prototype.format = function () {
            var args = arguments;
            return this.replace(/{(\d+)}/g, function (match, number) {
                return typeof args[number] != 'undefined'
                  ? args[number]
                  : match
                ;
            });
        };
    }

    var Restoran = function () {
        var that = this;

        //public properties
        this.loaded = false;
        this.initialized = false;

        this.currentToken = '';

        //public functions

        this.globalize = window.Globalize || {
            culture: function () {
                console.log(arguments);
            }
        };

        $.validator.methods.number = function (value, element) {
            return this.optional(element) ||
                !isNaN(Globalize.parseFloat(value));
        };

        $.validator.methods.date = function (value, element) {
            //This is not ideal but Chrome passes dates through in ISO1901 format regardless of locale 
            //and despite displaying in the specified format.

            return this.optional(element)
                || Globalize.parseDate(value, "dd/mm/yyyy", "pt-BR")
                || Globalize.parseDate(value, "yyyy-mm-dd");
        };


        this.getToken = function () {
            if (that.loaded) {
                if (that.currentToken.length == 0) {
                    var token = $('[name=__RequestVerificationToken]').val();
                    if (token)
                        that.currentToken = token;
                }
            }
            return that.currentToken;
        };

        this.initialize = function () {
            if (that.initialized)
                return;

            //do stuff
            that.globalize.culture(culture);

            that.initialized = true;
        };

        this.UpdateQueryString = function (key, value, url) {
            if (!url) url = window.location.href;
            var re = new RegExp("([?|&])" + key + "=.*?(&|#|$)(.*)", "gi");
            var hash;
            if (re.test(url)) {
                if (typeof value !== 'undefined' && value !== null)
                    return url.replace(re, '$1' + key + "=" + value + '$2$3');
                else {
                    hash = url.split('#');
                    url = hash[0].replace(re, '$1$3').replace(/(&|\?)$/, '');
                    if (typeof hash[1] !== 'undefined' && hash[1] !== null)
                        url += '#' + hash[1];
                    return url;
                }
            } else {
                if (typeof value !== 'undefined' && value !== null) {
                    hash = url.split('#');
                    var separator = url.indexOf('?') !== -1 ? '&' : '?';
                    url = hash[0] + separator + key + '=' + value;
                    if (typeof hash[1] !== 'undefined' && hash[1] !== null)
                        url += '#' + hash[1];
                    return url;
                } else
                    return url;
            }
        };

        return that;
    };

    var app = new Restoran();

    $(function () {
        app.initialize();
        app.loaded = true;

        $.ajaxSetup({
            headers: {
                "__RequestVerificationToken": app.getToken()
            }
        });

        //validação

        jQuery.extend(jQuery.validator.methods, {
            range: function (value, element, param) {
                //Use the Globalization plugin to parse the value        
                var val = Globalize.parseFloat(value);
                return this.optional(element) || (
                    val >= param[0] && val <= param[1]);
            }
        });

        $("form").bind("invalid-form.validate", function (form) {
            $('.bmvc-3-validation-summary').addClass('alert alert-danger').find('.close').show();
        });

        $.validator.setDefaults({
            highlight: function (element) {
                $(element).closest(".control-group").addClass("error");
                $(element).closest(".form-group").addClass("has-error");
            },
            unhighlight: function (element) {
                $(element).closest(".control-group").removeClass("error");
                $(element).closest(".form-group").removeClass("has-error");
            }
        });

        var hash = location.hash, hashPieces = hash.split('?'), activeTab = $("[href=' + hashPieces[0] + ']");
        activeTab && activeTab.tab('show');

    });

    window.Restoran = app;

})(window, 'pt-BR');